// ===== PROJECT DATA =====
// To add or edit a project, just change this list.
const projects = [
  {
    title: "Age Calculator",
    description: "A JavaScript app that works out your exact age from your date of birth.",
    url: "https://superlative-empanada-624819.netlify.app/",
    icon: "🎂",
    category: "tool",
    tags: ["HTML", "CSS", "JavaScript"],
    color: "linear-gradient(135deg, #f472b6, #a855f7)"
  },
  {
    title: "Music Player",
    description: "A music player page with cover art, song title, artist name and audio playback.",
    url: "https://musiqueofenoch.netlify.app/",
    icon: "🎵",
    category: "media",
    tags: ["HTML", "CSS", "JavaScript", "Audio"],
    color: "linear-gradient(135deg, #22c55e, #0ea5e9)"
  },
  {
    title: "Calculator",
    description: "A working calculator for everyday arithmetic, built with clean button layouts.",
    url: "https://calculatorforenoch.netlify.app/",
    icon: "🧮",
    category: "tool",
    tags: ["HTML", "CSS", "JavaScript"],
    color: "linear-gradient(135deg, #f59e0b, #ef4444)"
  },
  {
    title: "Fashion Store",
    description: "An online clothing and shoe shop showing sales, women's fashion and the latest trends.",
    url: "https://clothesshop2.netlify.app/",
    icon: "👗",
    category: "website",
    tags: ["HTML", "CSS", "Responsive"],
    color: "linear-gradient(135deg, #38bdf8, #6366f1)"
  },
  {
    title: "Web Project",
    description: "A front-end web project built with HTML, CSS and JavaScript.",
    url: "https://celadon-sorbet-96a304.netlify.app/",
    icon: "💻",
    category: "website",
    tags: ["HTML", "CSS", "JavaScript"],
    color: "linear-gradient(135deg, #14b8a6, #84cc16)"
  }
];

// ===== RENDER PROJECT CARDS =====
const grid = document.getElementById("projectsGrid");

projects.forEach((p) => {
  const card = document.createElement("div");
  card.className = "project-card reveal";
  card.dataset.category = p.category;
  card.innerHTML = `
    <div class="project-banner" style="background:${p.color}">${p.icon}</div>
    <div class="project-body">
      <h3>${p.title}</h3>
      <p>${p.description}</p>
      <div class="tags">${p.tags.map((t) => `<span class="tag">${t}</span>`).join("")}</div>
      <a href="${p.url}" target="_blank" rel="noopener" class="btn btn-primary">Live Demo ↗</a>
    </div>`;
  grid.appendChild(card);
});

// ===== PROJECT FILTERS =====
document.querySelectorAll(".filter").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelector(".filter.active").classList.remove("active");
    btn.classList.add("active");
    const f = btn.dataset.filter;
    document.querySelectorAll(".project-card").forEach((card) => {
      card.classList.toggle("hide", f !== "all" && card.dataset.category !== f);
    });
  });
});

// ===== TYPING EFFECT =====
const words = ["Student Developer", "Front-End Developer", "Web Designer", "Problem Solver"];
const typingEl = document.getElementById("typing");
let wordIndex = 0, charIndex = 0, deleting = false;

function type() {
  const word = words[wordIndex];
  typingEl.textContent = word.substring(0, charIndex);

  if (!deleting && charIndex < word.length) {
    charIndex++;
    setTimeout(type, 100);
  } else if (deleting && charIndex > 0) {
    charIndex--;
    setTimeout(type, 50);
  } else {
    deleting = !deleting;
    if (!deleting) wordIndex = (wordIndex + 1) % words.length;
    setTimeout(type, deleting ? 1500 : 300);
  }
}
type();

// ===== MOBILE MENU =====
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => navLinks.classList.toggle("open"));
navLinks.querySelectorAll("a").forEach((a) =>
  a.addEventListener("click", () => navLinks.classList.remove("open"))
);

// ===== DARK / LIGHT MODE =====
const themeToggle = document.getElementById("themeToggle");
try {
  if (localStorage.getItem("theme") === "light") {
    document.body.classList.add("light");
    themeToggle.textContent = "☀️";
  }
} catch (e) {}

themeToggle.addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light");
  themeToggle.textContent = isLight ? "☀️" : "🌙";
  try { localStorage.setItem("theme", isLight ? "light" : "dark"); } catch (e) {}
});

// ===== NAVBAR, ACTIVE LINK & BACK-TO-TOP ON SCROLL =====
const navbar = document.getElementById("navbar");
const backToTop = document.getElementById("backToTop");
const sections = document.querySelectorAll("section[id]");

window.addEventListener("scroll", () => {
  navbar.classList.toggle("scrolled", window.scrollY > 50);
  backToTop.classList.toggle("show", window.scrollY > 400);

  let current = "home";
  sections.forEach((s) => {
    if (window.scrollY >= s.offsetTop - 150) current = s.id;
  });
  document.querySelectorAll(".nav-links a").forEach((a) => {
    a.classList.toggle("active", a.getAttribute("href") === "#" + current);
  });
});

backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// ===== SCROLL REVEAL, SKILL BARS & COUNTERS =====
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add("visible");

    entry.target.querySelectorAll(".fill").forEach((f) => (f.style.width = f.dataset.width));

    entry.target.querySelectorAll(".counter").forEach((c) => {
      const target = +c.dataset.target;
      let n = 0;
      const step = Math.max(1, Math.ceil(target / 50));
      const timer = setInterval(() => {
        n += step;
        if (n >= target) { n = target; clearInterval(timer); }
        c.textContent = n;
      }, 30);
    });

    observer.unobserve(entry.target);
  });
}, { threshold: 0.2 });

document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));

// ===== CONTACT FORM (sends messages to Enoch's email via FormSubmit) =====
const FORM_ENDPOINT = "https://formsubmit.co/ajax/enochdaranola@gmail.com";
const contactForm = document.getElementById("contactForm");
const formMsg = document.getElementById("formMsg");
const sendBtn = document.getElementById("sendBtn");

contactForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Stop spam bots that fill the hidden field
  if (contactForm.elements["_honey"].value) return;

  const name = contactForm.elements["name"].value.trim();
  const data = {
    name: name,
    email: contactForm.elements["email"].value.trim(),
    message: contactForm.elements["message"].value.trim(),
    _subject: `New portfolio message from ${name}`,
    _replyto: contactForm.elements["email"].value.trim(),
    _template: "table",
    _captcha: "false"
  };

  sendBtn.disabled = true;
  sendBtn.textContent = "Sending...";
  formMsg.style.color = "";
  formMsg.textContent = "";

  // FormSubmit does not work when the page is opened as a local file
  if (location.protocol === "file:") {
    formMsg.style.color = "#f87171";
    formMsg.textContent = "Please test the form on your live Netlify link, not a file opened from your computer.";
    sendBtn.disabled = false;
    sendBtn.textContent = "Send Message";
    return;
  }

  try {
    const res = await fetch(FORM_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(data)
    });
    const result = await res.json().catch(() => ({}));
    const ok = res.ok && String(result.success) !== "false";

    if (ok) {
      formMsg.textContent = `Thank you, ${name}! Your message has been sent. I'll reply soon.`;
      contactForm.reset();
    } else if (/activat/i.test(result.message || "")) {
      // First-ever submission: FormSubmit emails Enoch an activation link
      formMsg.style.color = "#facc15";
      formMsg.textContent = "Almost there! Check enochdaranola@gmail.com (and Spam) for the FormSubmit 'Activate Form' email, click it, then send again.";
    } else {
      throw new Error(result.message || `Error ${res.status}`);
    }
  } catch (err) {
    console.error("Contact form error:", err);
    formMsg.style.color = "#f87171";
    formMsg.textContent = `Sorry, the message could not be sent (${err.message}). Please try again.`;
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send Message";
  }
});

// ===== FOOTER YEAR =====
document.getElementById("year").textContent = new Date().getFullYear();
